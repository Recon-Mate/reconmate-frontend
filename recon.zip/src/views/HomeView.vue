<template>
  <app-navbar></app-navbar>
  <div class="min-h-screen bg-gray-100 font-Lexend">
    

    <div class="flex flex-col md:flex-row items-center justify-between p-8 md:p-16 lg:p-20">
      <div class="md:w-1/2 space-y-4">
        <h2 class="text-xl md:text-2xl lg:text-3xl font-semibold">Halo, Welcome to Recon Mate</h2>
        <h1 class="text-3xl md:text-4xl lg:text-5xl font-bold text-blue-900 leading-tight">
          Velit anim proident fugiat et qui veniam pariatur dui
        </h1>
        <p class="text-base md:text-lg lg:text-xl text-gray-600">
          Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        </p>
        <a href="#" class="inline-flex items-center bg-blue-900 text-white text-sm md:text-base lg:text-lg px-4 py-2 md:px-5 md:py-3 lg:px-6 lg:py-4 rounded">
          <i class="fa fa-book mr-2"></i> Temukan
        </a>
      </div>

      <div class="md:w-1/2 flex justify-center mt-8 md:mt-0">
        <img src="@/assets/Recon.png" alt="Bug" class="w-2/3 md:w-3/4 lg:w-1/2">
      </div>
    </div>
  </div>
</template>

<script>
import AppNavbar from '@/components/AppNavbar.vue';

export default {
  name: 'HomeView',
  components: {
    AppNavbar
  }
};
</script>

<style>
@import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');
@import url('https://fonts.googleapis.com/css2?family=Lexend:wght@400;700&display=swap');
</style>
