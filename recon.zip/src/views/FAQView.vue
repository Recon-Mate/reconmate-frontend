<template>
  <app-navbar></app-navbar>
  <div class="p-8 md:p-16 lg:p-20">
    <h2 class="text-xl md:text-2xl lg:text-3xl font-semibold">Frequently Asked Questions</h2>
    <p class="text-base md:text-lg lg:text-xl text-gray-600 mt-4">
      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
    </p>
  </div>
</template>

<script>
import AppNavbar from '@/components/AppNavbar.vue';

export default {
  name: 'FAQView',
  components: {
    AppNavbar
  }
};
</script>

<style>
/* Add any additional styles here */
</style>
